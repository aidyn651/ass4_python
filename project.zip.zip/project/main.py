from analytics import FileManager
from analytics import DataLoader
from analytics import ResultSaver
from analytics import Report

from analytics.analyser import (
    TopStudentsAnalyser,
    CountryAnalyser
)


fm = FileManager('students.csv')

fm.check_file()

fm.create_output_folder()


dl = DataLoader('students.csv')

dl.load()

dl.preview()


print('-----------------------------')
print('Running all analysers:')
print('-----------------------------')


analysers = [

    TopStudentsAnalyser(dl.students),

    CountryAnalyser(dl.students[:10])

]


for a in analysers:

    print(a)

    a.analyse()

    a.print_results()


saver = ResultSaver(
    analysers[0].result,
    'output/result.json'
)


report = Report(
    analysers[0],
    saver
)

report.generate()
